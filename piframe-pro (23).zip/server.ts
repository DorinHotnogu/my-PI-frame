import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import multer from 'multer';
import sharp from 'sharp';
import cors from 'cors';
import { exec, execSync } from 'child_process';
import Database from 'better-sqlite3';

const app = express();
const PORT = 3000;

// Database Setup
const db = new Database('piframe.db');
db.exec(`
  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
  );
  CREATE TABLE IF NOT EXISTS albums (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS photos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    album_id INTEGER,
    filename TEXT NOT NULL,
    original_name TEXT,
    order_index INTEGER DEFAULT 0,
    FOREIGN KEY(album_id) REFERENCES albums(id) ON DELETE CASCADE
  );
  CREATE TABLE IF NOT EXISTS schedule (
    day_type TEXT PRIMARY KEY, -- 'weekday', 'weekend'
    start_time TEXT,
    end_time TEXT,
    enabled INTEGER DEFAULT 1
  );
  CREATE TABLE IF NOT EXISTS ambilight (
    key TEXT PRIMARY KEY,
    value TEXT
  );
`);

// Initial Ambilight Settings
const defaultAmbilight = [
  ['enabled', '0'],
  ['brightness', '128'],
  ['leds_top', '20'],
  ['leds_right', '15'],
  ['leds_bottom', '20'],
  ['leds_left', '15'],
  ['start_corner', 'bottom-left'],
  ['direction', 'cw'],
  ['smoothing', '0.5'],
  ['sample_depth', '10'], // How deep into the image to sample for edge colors
  ['mode', 'dynamic'], // 'dynamic' or 'static'
  ['static_color', '#ffffff']
];
const insertAmbilight = db.prepare('INSERT OR IGNORE INTO ambilight (key, value) VALUES (?, ?)');
defaultAmbilight.forEach(s => insertAmbilight.run(s[0], s[1]));

// Initial Schedule
const defaultSchedule = [
  ['weekday', '08:00', '22:00', 1],
  ['weekend', '09:00', '23:00', 1]
];
const insertSchedule = db.prepare('INSERT OR IGNORE INTO schedule (day_type, start_time, end_time, enabled) VALUES (?, ?, ?, ?)');
defaultSchedule.forEach(s => insertSchedule.run(s[0], s[1], s[2], s[3]));

// Initial Settings
const defaultSettings = [
  ['duration', '10000'],
  ['crossfade', '5000'],
  ['ken_burns_enabled', '1'],
  ['ken_burns_intensity', '0.5'],
  ['current_album_id', '1'],
  ['is_playing', '1'],
  ['refresh_token', Date.now().toString()],
  ['shuffle_enabled', '0'],
  ['brightness', '1.0']
];

const insertSetting = db.prepare('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)');
defaultSettings.forEach(s => insertSetting.run(s[0], s[1]));

// Default Album
const albumsCount = db.prepare('SELECT COUNT(*) as count FROM albums').get() as any;
if (albumsCount.count === 0) {
  db.prepare('INSERT INTO albums (id, name) VALUES (1, ?)').run('Albumul meu');
} else {
  // Migration: rename "Album Implicit" to "Albumul meu" if it exists
  db.prepare("UPDATE albums SET name = 'Albumul meu' WHERE name = 'Album Implicit'").run();
}

// Ensure directories exist
const UPLOADS_DIR = path.join(process.cwd(), 'uploads');
const PROCESSED_DIR = path.join(process.cwd(), 'processed');
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR);
if (!fs.existsSync(PROCESSED_DIR)) fs.mkdirSync(PROCESSED_DIR);

// Multer config
const storage = multer.diskStorage({
  destination: UPLOADS_DIR,
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  }
});
const upload = multer({ storage });

app.use(cors());
app.use(express.json());
app.use('/photos', express.static(PROCESSED_DIR));

// --- LED Control Mock/Real ---
let ws281x: any = null;
let ledsInitialized = false;
let ledProcess: any = null;

async function initLeds() {
  if (ledsInitialized) return;
  
  const ambilightSettings = getAmbilightSettings();
  if (ambilightSettings.enabled !== '1') return;

  const totalLeds = 
    parseInt(ambilightSettings.leds_top) + 
    parseInt(ambilightSettings.leds_right) + 
    parseInt(ambilightSettings.leds_bottom) + 
    parseInt(ambilightSettings.leds_left);

  try {
    // Try to load the real library
    // @ts-ignore
    const mod = await import('rpi-ws281x-native');
    ws281x = mod.default || mod;
    
    ws281x.init({
      count: totalLeds,
      gpio: 18,
      brightness: parseInt(ambilightSettings.brightness),
      stripType: 'ws2812'
    });
    
    ledsInitialized = true;
    console.log(`LEDs initialized: ${totalLeds} LEDs on GPIO 18`);
  } catch (err) {
    console.warn("LED library not found or failed to init. Using mock.");
    // Mock implementation
    ws281x = {
      render: (data: Uint32Array) => {
        // Mock render
      },
      reset: () => {},
      setBrightness: (b: number) => {}
    };
    ledsInitialized = true;
  }
}

function getAmbilightSettings() {
  const rows = db.prepare('SELECT * FROM ambilight').all();
  return rows.reduce((acc: any, curr: any) => {
    acc[curr.key] = curr.value;
    return acc;
  }, {});
}

async function updateAmbilight(photoFilename: string) {
  const settings = getAmbilightSettings();
  if (settings.enabled !== '1') {
    if (ws281x && ledsInitialized) {
      const totalLeds = 
        parseInt(settings.leds_top) + 
        parseInt(settings.leds_right) + 
        parseInt(settings.leds_bottom) + 
        parseInt(settings.leds_left);
      ws281x.render(new Uint32Array(totalLeds));
    }
    return;
  }

  await initLeds();

  const topCount = parseInt(settings.leds_top);
  const rightCount = parseInt(settings.leds_right);
  const bottomCount = parseInt(settings.leds_bottom);
  const leftCount = parseInt(settings.leds_left);
  const totalCount = topCount + rightCount + bottomCount + leftCount;

  if (settings.mode === 'static') {
    const colorHex = settings.static_color || '#ffffff';
    const r = parseInt(colorHex.slice(1, 3), 16);
    const g = parseInt(colorHex.slice(3, 5), 16);
    const b = parseInt(colorHex.slice(5, 7), 16);
    const colorInt = (r << 16) | (g << 8) | b;
    
    const ledData = new Uint32Array(totalCount).fill(colorInt);
    if (ws281x) ws281x.render(ledData);
    return;
  }

  const photoPath = path.join(PROCESSED_DIR, photoFilename);
  if (!fs.existsSync(photoPath)) return;

  try {
    const depth = parseInt(settings.sample_depth) || 10;
    
    const image = sharp(photoPath);
    const metadata = await image.metadata();
    if (!metadata.width || !metadata.height) return;

    const getAverageColor = async (left: number, top: number, width: number, height: number) => {
      try {
        const buffer = await sharp(photoPath)
          .extract({ 
            left: Math.max(0, Math.floor(left)), 
            top: Math.max(0, Math.floor(top)), 
            width: Math.min(metadata.width! - Math.floor(left), Math.floor(width)), 
            height: Math.min(metadata.height! - Math.floor(top), Math.floor(height)) 
          })
          .resize(1, 1)
          .raw()
          .toBuffer();
        return (buffer[0] << 16) | (buffer[1] << 8) | buffer[2];
      } catch (e) {
        return 0;
      }
    };

    const segments: number[] = [];

    // TOP (Left to Right)
    for (let i = 0; i < topCount; i++) {
      const x = (i / topCount) * metadata.width;
      const w = metadata.width / topCount;
      segments.push(await getAverageColor(x, 0, w, depth));
    }

    // RIGHT (Top to Bottom)
    for (let i = 0; i < rightCount; i++) {
      const y = (i / rightCount) * metadata.height;
      const h = metadata.height / rightCount;
      segments.push(await getAverageColor(metadata.width - depth, y, depth, h));
    }

    // BOTTOM (Right to Left)
    for (let i = bottomCount - 1; i >= 0; i--) {
      const x = (i / bottomCount) * metadata.width;
      const w = metadata.width / bottomCount;
      segments.push(await getAverageColor(x, metadata.height - depth, w, depth));
    }

    // LEFT (Bottom to Top)
    for (let i = leftCount - 1; i >= 0; i--) {
      const y = (i / leftCount) * metadata.height;
      const h = metadata.height / leftCount;
      segments.push(await getAverageColor(0, y, depth, h));
    }

    let finalOrder = [...segments];
    if (settings.direction === 'ccw') finalOrder.reverse();
    
    let shift = 0;
    if (settings.start_corner === 'top-right') shift = topCount;
    if (settings.start_corner === 'bottom-right') shift = topCount + rightCount;
    if (settings.start_corner === 'bottom-left') shift = topCount + rightCount + bottomCount;
    
    if (shift > 0) {
      const part = finalOrder.splice(0, shift);
      finalOrder = [...finalOrder, ...part];
    }

    const ledData = new Uint32Array(totalCount);
    for (let i = 0; i < totalCount; i++) ledData[i] = finalOrder[i];

    if (ws281x) ws281x.render(ledData);
  } catch (err) {
    console.error("Ambilight update error:", err);
  }
}

// --- API ROUTES ---

// Settings
app.get('/api/settings', (req, res) => {
  const settings = db.prepare('SELECT * FROM settings').all();
  const settingsObj = settings.reduce((acc: any, curr: any) => {
    acc[curr.key] = curr.value;
    return acc;
  }, {});
  res.json(settingsObj);
});

app.post('/api/settings', (req, res) => {
  const { key, value } = req.body;
  db.prepare('UPDATE settings SET value = ? WHERE key = ?').run(value.toString(), key);
  
  if (key === 'is_playing' || key === 'duration') {
    startAutoAdvance();
  }
  
  res.json({ success: true });
});

// Albums
app.get('/api/albums', (req, res) => {
  const albums = db.prepare('SELECT * FROM albums').all();
  res.json(albums);
});

app.post('/api/albums', (req, res) => {
  const { name } = req.body;
  const result = db.prepare('INSERT INTO albums (name) VALUES (?)').run(name);
  res.json({ id: result.lastInsertRowid, name });
});

app.delete('/api/albums/:id', (req, res) => {
  const { id } = req.params;
  // Delete physical files first? For now just DB
  db.prepare('DELETE FROM albums WHERE id = ?').run(id);
  res.json({ success: true });
});

app.patch('/api/albums/:id', (req, res) => {
  const { id } = req.params;
  const { name } = req.body;
  db.prepare('UPDATE albums SET name = ? WHERE id = ?').run(name, id);
  res.json({ success: true });
});

// Photos
app.get('/api/albums/:id/photos', (req, res) => {
  const { id } = req.params;
  let photos;
  if (id === 'all') {
    photos = db.prepare('SELECT * FROM photos ORDER BY order_index ASC').all();
  } else {
    photos = db.prepare('SELECT * FROM photos WHERE album_id = ? ORDER BY order_index ASC').all(id);
  }
  res.json(photos);
});

app.post('/api/upload', upload.array('photos'), async (req, res) => {
  const { album_id } = req.body;
  const files = req.files as Express.Multer.File[];
  
  const processedFiles = [];

  for (const file of files) {
    const outputFilename = `processed-${file.filename}.jpg`;
    const outputPath = path.join(PROCESSED_DIR, outputFilename);

    // Image Processing: 9:16 Portrait
    // Target: 1080x1920 (standard HD portrait)
    // Fit to height, crop sides if necessary to fill
    await sharp(file.path)
      .resize({
        width: 1080,
        height: 1920,
        fit: 'cover', // This ensures it fills the 9:16 area, cropping if needed
        position: 'center'
      })
      .jpeg({ quality: 90 })
      .toFile(outputPath);

    const result = db.prepare('INSERT INTO photos (album_id, filename, original_name) VALUES (?, ?, ?)')
      .run(album_id, outputFilename, file.originalname);
    
    processedFiles.push({ id: result.lastInsertRowid, filename: outputFilename });
  }

  res.json(processedFiles);
});

app.delete('/api/photos/:id', (req, res) => {
  const photo = db.prepare('SELECT filename FROM photos WHERE id = ?').get(req.params.id) as any;
  if (photo) {
    const filePath = path.join(PROCESSED_DIR, photo.filename);
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    db.prepare('DELETE FROM photos WHERE id = ?').run(req.params.id);
  }
  res.json({ success: true });
});

app.post('/api/photos/:id/move', (req, res) => {
  const { album_id } = req.body;
  db.prepare('UPDATE photos SET album_id = ? WHERE id = ?').run(album_id, req.params.id);
  res.json({ success: true });
});

app.post('/api/photos/:id/copy', (req, res) => {
  const { album_id } = req.body;
  const photo = db.prepare('SELECT * FROM photos WHERE id = ?').get(req.params.id) as any;
  if (photo) {
    db.prepare('INSERT INTO photos (album_id, filename, original_name) VALUES (?, ?, ?)')
      .run(album_id, photo.filename, photo.original_name);
  }
  res.json({ success: true });
});

// System Tools
function getDisplayCommands(state: 'on' | 'off') {
  const USB_HUB = "1-1";
  const USB_PORT = "2";

  if (state === 'on') {
    return `sudo -n /usr/sbin/uhubctl -l ${USB_HUB} -p ${USB_PORT} -a on`;
  } else {
    return `sudo -n /usr/sbin/uhubctl -l ${USB_HUB} -p ${USB_PORT} -a off`;
  }
}

function setLedsOff() {
  if (ws281x && ledsInitialized) {
    const settings = getAmbilightSettings();
    const totalLeds = 
      parseInt(settings.leds_top) + 
      parseInt(settings.leds_right) + 
      parseInt(settings.leds_bottom) + 
      parseInt(settings.leds_left);
    ws281x.render(new Uint32Array(totalLeds));
  }
}

function updateLeds() {
  const settings = getAmbilightSettings();
  if (settings.enabled === '1') {
    // Trigger Ambilight update for current photo
    const albumId = db.prepare('SELECT value FROM settings WHERE key = ?').get('current_album_id') as any;
    let photos;
    if (albumId.value === 'all') {
      photos = db.prepare('SELECT * FROM photos ORDER BY order_index ASC').all();
    } else {
      photos = db.prepare('SELECT * FROM photos WHERE album_id = ? ORDER BY order_index ASC').all(albumId.value);
    }
    if (photos.length > 0 && currentPhotoIndex < photos.length) {
      updateAmbilight(photos[currentPhotoIndex].filename);
    }
  } else {
    setLedsOff();
  }
}

app.post('/api/system/:command', (req, res) => {
  const { command } = req.params;
  console.log(`System Command: ${command}`);
  
  let shellCmd = '';
  switch (command) {
    case 'screen_on':
      shellCmd = getDisplayCommands('on');
      updateLeds(); // Restore LEDs when screen turns on
      break;
    case 'screen_off':
      shellCmd = getDisplayCommands('off');
      setLedsOff(); // Turn off LEDs when screen turns off
      break;
    case 'restart_display':
      // Force client reload by updating refresh_token
      db.prepare("UPDATE settings SET value = ? WHERE key = 'refresh_token'").run(Date.now().toString());
      res.json({ success: true, message: 'Refresh signal sent to frame' });
      return;
    case 'reboot':
      shellCmd = 'sudo reboot';
      break;
    default:
      return res.status(400).json({ error: 'Invalid command' });
  }

  if (process.env.NODE_ENV === 'production') {
    exec(shellCmd, (err, stdout, stderr) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ success: true, stdout });
    });
  } else {
    res.json({ success: true, message: `Simulated: ${shellCmd}` });
  }
});

// Ambilight API
app.get('/api/ambilight', (req, res) => {
  const settings = db.prepare('SELECT * FROM ambilight').all();
  const settingsObj = settings.reduce((acc: any, curr: any) => {
    acc[curr.key] = curr.value;
    return acc;
  }, {});
  res.json(settingsObj);
});

app.post('/api/ambilight', (req, res) => {
  const { key, value } = req.body;
  db.prepare('UPDATE ambilight SET value = ? WHERE key = ?').run(value.toString(), key);
  
  // If enabled changed, we might need to reset LEDs or init them
  if (key === 'enabled' || key === 'brightness' || key.startsWith('leds_')) {
    ledsInitialized = false; // Force re-init on next update
    if (ws281x && ws281x.reset) ws281x.reset();
  }

  updateLeds();
  res.json({ success: true });
});

// Schedule
app.get('/api/schedule', (req, res) => {
  const schedule = db.prepare('SELECT * FROM schedule').all();
  res.json(schedule);
});

app.post('/api/schedule', (req, res) => {
  const { day_type, start_time, end_time, enabled } = req.body;
  db.prepare(`
    INSERT INTO schedule (day_type, start_time, end_time, enabled)
    VALUES (?, ?, ?, ?)
    ON CONFLICT(day_type) DO UPDATE SET
      start_time = excluded.start_time,
      end_time = excluded.end_time,
      enabled = excluded.enabled
  `).run(day_type, start_time, end_time, enabled ? 1 : 0);
  res.json({ success: true });
});

// Slideshow state
let currentPhotoIndex = 0;
let lastIndices: number[] = [];
let autoAdvanceTimer: NodeJS.Timeout | null = null;

async function advanceSlideshow() {
  const settings = db.prepare('SELECT value FROM settings WHERE key = ?').get('shuffle_enabled') as any;
  const albumId = db.prepare('SELECT value FROM settings WHERE key = ?').get('current_album_id') as any;
  
  let photos;
  if (albumId.value === 'all') {
    photos = db.prepare('SELECT * FROM photos ORDER BY order_index ASC').all();
  } else {
    photos = db.prepare('SELECT * FROM photos WHERE album_id = ? ORDER BY order_index ASC').all(albumId.value);
  }
  
  if (photos.length > 0) {
    if (settings?.value === '1' && photos.length > 1) {
      let nextIndex = currentPhotoIndex;
      let attempts = 0;
      const maxHistory = Math.floor(photos.length * 0.7);
      
      while (attempts < 20) {
        nextIndex = Math.floor(Math.random() * photos.length);
        if (!lastIndices.includes(nextIndex) && nextIndex !== currentPhotoIndex) break;
        attempts++;
      }
      
      currentPhotoIndex = nextIndex;
      lastIndices.push(currentPhotoIndex);
      if (lastIndices.length > maxHistory) lastIndices.shift();
    } else {
      currentPhotoIndex = (currentPhotoIndex + 1) % photos.length;
      lastIndices = [];
    }
    
    // Update Ambilight for the new photo
    updateAmbilight(photos[currentPhotoIndex].filename);
  }
  triggerRefresh();
}

function startAutoAdvance() {
  if (autoAdvanceTimer) clearInterval(autoAdvanceTimer);
  
  const settings = db.prepare('SELECT * FROM settings').all();
  const settingsObj = settings.reduce((acc: any, curr: any) => {
    acc[curr.key] = curr.value;
    return acc;
  }, {});

  if (settingsObj.is_playing === '1') {
    const duration = parseInt(settingsObj.duration) || 5000;
    autoAdvanceTimer = setInterval(() => {
      advanceSlideshow();
    }, duration);
  }
}

// Start on boot
setTimeout(startAutoAdvance, 2000);

app.get('/api/pi/stats', (req, res) => {
  const now = new Date();
  const timeStr = now.toLocaleString('ro-RO', { hour12: false });

  if (process.env.NODE_ENV === 'production') {
    try {
      const tempOutput = execSync('vcgencmd measure_temp').toString();
      const temp = tempOutput.replace('temp=', '').replace("'C\n", '').trim();
      
      const cpuOutput = execSync("top -bn1 | grep 'Cpu(s)' | sed 's/.*, *\\([0-9.]*\\)%* id.*/\\1/' | awk '{print 100 - $1}'").toString().trim();
      
      const ramOutput = execSync("free -m | awk '/Mem:/ { print $3 \",\" $2 }'").toString().trim();
      const [ramUsed, ramTotal] = ramOutput.split(',');
      
      res.json({ 
        temp, 
        cpu: parseFloat(cpuOutput).toFixed(1),
        ramUsed,
        ramTotal,
        time: timeStr
      });
    } catch (err) {
      res.json({ temp: 'N/A', cpu: 'N/A', ramUsed: '0', ramTotal: '0', time: timeStr });
    }
  } else {
    // Mock for dev
    res.json({ 
      temp: (40 + Math.random() * 10).toFixed(1),
      cpu: (10 + Math.random() * 20).toFixed(1),
      ramUsed: '450',
      ramTotal: '1024',
      time: timeStr
    });
  }
});

app.post('/api/system/time', (req, res) => {
  const { datetime } = req.body;
  if (!datetime) return res.status(400).json({ error: 'Missing datetime' });

  if (process.env.NODE_ENV === 'production') {
    exec(`sudo date -s "${datetime}"`, (err) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ success: true });
    });
  } else {
    console.log(`[System] Simulated time set to: ${datetime}`);
    res.json({ success: true });
  }
});

app.get('/api/slideshow/current', (req, res) => {
  const settings = db.prepare('SELECT * FROM settings').all();
  const settingsObj = settings.reduce((acc: any, curr: any) => {
    acc[curr.key] = curr.value;
    return acc;
  }, {});

  let photos;
  if (settingsObj.current_album_id === 'all') {
    photos = db.prepare('SELECT * FROM photos ORDER BY order_index ASC').all();
  } else {
    photos = db.prepare('SELECT * FROM photos WHERE album_id = ? ORDER BY order_index ASC').all(settingsObj.current_album_id);
  }
  
  if (photos.length === 0) return res.json({ photo: null, settings: settingsObj });
  
  if (currentPhotoIndex >= photos.length) currentPhotoIndex = 0;
  if (currentPhotoIndex < 0) currentPhotoIndex = photos.length - 1;
  
  const currentPhoto = photos[currentPhotoIndex];
  updateAmbilight(currentPhoto.filename);

  res.json({ 
    photo: currentPhoto, 
    settings: settingsObj,
    total: photos.length,
    index: currentPhotoIndex
  });
});

function triggerRefresh() {
  db.prepare("UPDATE settings SET value = ? WHERE key = 'refresh_token'").run(Date.now().toString());
}

app.post('/api/settings', (req, res) => {
  const { key, value } = req.body;
  db.prepare('UPDATE settings SET value = ? WHERE key = ?').run(value.toString(), key);
  
  // Trigger refresh for all settings changes so slideshow picks them up immediately
  triggerRefresh();
  
  // Restart timer if duration or is_playing changed
  if (key === 'duration' || key === 'is_playing' || key === 'current_album_id') {
    startAutoAdvance();
  }
  
  res.json({ success: true });
});

app.post('/api/slideshow/next', (req, res) => {
  advanceSlideshow();
  // Reset timer on manual command
  startAutoAdvance();
  res.json({ success: true });
});

app.post('/api/slideshow/prev', (req, res) => {
  const albumId = db.prepare('SELECT value FROM settings WHERE key = ?').get('current_album_id') as any;
  
  let photos;
  if (albumId.value === 'all') {
    photos = db.prepare('SELECT id FROM photos ORDER BY order_index ASC').all();
  } else {
    photos = db.prepare('SELECT id FROM photos WHERE album_id = ? ORDER BY order_index ASC').all(albumId.value);
  }

  if (photos.length > 0) {
    currentPhotoIndex = (currentPhotoIndex - 1 + photos.length) % photos.length;
  }
  triggerRefresh();
  // Reset timer on manual command
  startAutoAdvance();
  res.json({ success: true });
});

// Schedule Enforcer
let lastScheduleState: 'on' | 'off' | null = null;

setInterval(() => {
  const now = new Date();
  const isWeekend = now.getDay() === 0 || now.getDay() === 6;
  const dayType = isWeekend ? 'weekend' : 'weekday';
  const currentTime = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');

  const schedule = db.prepare('SELECT * FROM schedule WHERE day_type = ?').get(dayType) as any;
  
  if (schedule && schedule.enabled) {
    // Use exclusive end time for better behavior (e.g. 22:00 means it turns off at 22:00)
    const isWithinWindow = currentTime >= schedule.start_time && currentTime < schedule.end_time;
    const newState = isWithinWindow ? 'on' : 'off';
    
    // Only execute if state changed to avoid redundant shell calls
    if (newState !== lastScheduleState) {
      console.log(`[Schedule] Transitioning to ${newState} (Day: ${dayType}, Time: ${currentTime})`);
      const shellCmd = getDisplayCommands(newState);
      
      if (process.env.NODE_ENV === 'production') {
        exec(shellCmd, (err) => {
          if (!err) {
            lastScheduleState = newState;
            if (newState === 'on') {
              updateLeds();
            } else {
              setLedsOff();
            }
          } else {
            console.error(`[Schedule] Error executing command: ${err.message}`);
          }
        });
      } else {
        console.log(`[Schedule] ${dayType} ${currentTime} -> ${newState} (Simulated: ${shellCmd})`);
        lastScheduleState = newState;
        if (newState === 'on') {
          updateLeds();
        } else {
          setLedsOff();
        }
      }
    }
  }
}, 30000); // Check every 30 seconds for better responsiveness

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
    
    // Disable screen blanking on startup if in production
    if (process.env.NODE_ENV === 'production') {
      exec('DISPLAY=:0 xset s off; DISPLAY=:0 xset -dpms; DISPLAY=:0 xset s noblank', (err) => {
        if (err) console.error('Failed to disable screen blanking:', err.message);
        else console.log('Screen blanking disabled');
      });
    }
  });
}

startServer();
